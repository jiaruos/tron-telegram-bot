<?php

namespace app\api\controller;

use app\common\controller\Api;
use app\api\model\User;
use Longman\TelegramBot\Request;
use Tg\TgBot;
use think\Cache;
use Tron\Address;

/**
 * Tg接口
 */
class Tg extends Api
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = ['*'];

    /**
     * 回调
     *
     */
    public function hook()
    {
        $bot_id = $this->request->get('id',0); //机器人id
        $content = file_get_contents("php://input");
        file_put_contents("tg.txt",$content,FILE_APPEND);

        $update = json_decode($content, true);
        if(!$update){
            exit('error');
        }
        if(!isset($update["message"])){
            exit('error');
        }
        $message = $update["message"];
        $message_id = $message['message_id']; //第几条消息
        $chat_id = $message['chat']['id']; //聊天id
        $from = $message['from']; //用户
        $TgBot = new TgBot($bot_id);
        $bot = $TgBot->getBot();
        if (isset($message['text'])) { //发送内容

            // incoming text message
            $text = $message['text'];
            if($text == "/start"){ //新用户
                $this->start($from,$bot_id,$chat_id,$bot,$message);
            }else if($text == "提醒列表"){ //新用户
                $this->listeners($chat_id,$message);
            }elseif(preg_match("/=/",$text) == 1){ //如果匹配上 =
                if(preg_match("/^del=/",$text) == 1){ //删除监听地址
                    $this->del_listeners($text,$chat_id,$message);
                }else{ //添加地址
                    $data = explode('=', $text);
                    $address = $data[0]; //可监听的交易地址
                    $bak = isset($data[1]) ? $data[1] : ''; //备注
                    $this->add_listeners($address,$chat_id,$message,$bak);
                }
            }else{
                $Address = new Address($text);
                if($Address->isValid()){
                    $this->add_listeners($text,$chat_id,$message,"");
                }else{
                    $send_content = db('tg_auto_reply')->where('keyword',$text)->value('content');
                    if(!$send_content){
                        $this->sendMessage($chat_id,$message_id,$bot['welcome']);
                    }else{
                        $this->sendMessage($chat_id,$message_id,$send_content);
                    }
                }
                
            }
            db('user')->where(['tg_id'=>$from['id']])->update(['activation'=>'1','updatetime'=>time()]);
        }
    }
    protected function start($from,$bot_id,$chat_id,$bot,$message){
        $_keyboard = config('site.keyboard');
        ksort($_keyboard);
        $keyboard = [];
        foreach($_keyboard as $v){
            $keyboard[] = ['text'=>$v];
        };
        $keyboard = array_chunk($keyboard,3);
        $User = new User();
        $find_user = $User->checkUser($from,$chat_id);
        if(!$find_user){
            $User->createUser($from,$bot_id,$chat_id);
        }
        $replyMarkup =[ 
            'keyboard' =>$keyboard,
            'resize_keyboard'=>true, 
            'one_time_keyboard'=>false, 
        ];
        $encodedMarkup = json_encode($replyMarkup); 
        Request::sendMessage([
            'chat_id'   => $chat_id,
            'text'      => $bot['welcome'],
            'reply_to_message_id' => $message['message_id'],
            'reply_markup'  => $replyMarkup
        ]);

    }
    protected function sendMessage($chat_id,$message_id,$msg){
        Request::sendMessage([
            'chat_id'   => $chat_id,
            'text'      => $msg,
            'reply_to_message_id' => $message_id,
            'parse_mode'    =>"HTML"
        ]);
    }
    /**
     * 添加监听地址
     */
    protected function add_listeners($address,$chat_id,$message,$bak=''){
        $address = trim($address);
        if(!$address){
            $this->sendMessage($chat_id,$message['message_id'],"你发送的格式不对");
            return false;
        }
        if(db('tg_address')->where('address',$address)->count()){
            $this->sendMessage($chat_id,$message['message_id'],"地址已绑定过或被他人绑定");
            return false;
        }
        
        $Address = new Address($address);
        if(!$Address->isValid()){
            $this->sendMessage($chat_id,$message['message_id'],"你发送的格式不对");
            return false;
        }
        $user = db('user')->field('id,tg_id,bot_id,listeners_counts')->where(['tg_id'=>$message['from']['id']])->find();
        if(!$user){
            $this->sendMessage($chat_id,$message['message_id'],"找不到相关用户，请重新发送 /start 进行激活");
            return false;
        }
        $count = db('tg_address')->where('tg_id',$message['from']['id'])->count();
        $listeners_counts = config('site.free_listen_counts') + $user['listeners_counts'];
        if($count >= $listeners_counts){ //超出免费提醒次数
            $this->sendMessage($chat_id,$message['message_id'],config('site.listen_tip'));
            return false;
        }
        $id = db('tg_address')->insertGetId([
            'user_id'   => $user['id'],
            'bot_id'    => $user['bot_id'],
            'tg_id' => $message['from']['id'],
            'address'   => $address,
            'createtime' => time(),
            'bak'       => $bak
        ]);
        if($id > 0){
            Cache::store('redis')->handler()->SADD('listens',$address);
            $this->sendMessage($chat_id,$message['message_id'],"绑定成功 这个地址有trx 或 usdt进账会发聊天消息给你^.^");
            return true;
        }
        $this->sendMessage($chat_id,$message['message_id'],"绑定失败，请重新绑定");
    }
    /**
     * 删除监听地址
     */ 
    protected function del_listeners($text,$chat_id,$message){
        
        $data = explode('=', $text);
        $address = $data[1]; //可监听的交易地址
        $address = trim($address);
        $find = db('tg_address')->where(['tg_id'=>$message['from']['id'],'address'=>$address])->find();
        if(!$find){
            $this->sendMessage($chat_id,$message['message_id'],"你没有绑定这个地址，无法删除");
            return false;
        }
        db('tg_address')->where(['id'=>$find['id']])->delete();
        Cache::store('redis')->handler()->SREM('listens',$address);
        $this->sendMessage($chat_id,$message['message_id'],"删除监听地址成功");
    }
    /**
     * 监听列表
     */
    protected function listeners($chat_id,$message){
        $list = db('tg_address')->field('id,address,bak')->where(['tg_id'=>$message['from']['id']])->order('createtime asc')->select();
        if(!$list){
            $this->sendMessage($chat_id,$message['message_id'],"你没有绑定过监听地址");
            return false;
        }
        $content = '';
        foreach ($list as $key => $value) {
            $value['address'] = "<code>".$value['address']."</code>";
            if($value['bak']){
                $value['address'] = $value['address'] .'='.$value['bak'];
            }
            $content .= $value['address'] . '
';
        }
        $this->sendMessage($chat_id,$message['message_id'],$content);
        return false;

    }
}
